package com.userservice.user;

public record UserResponse(
        String email
) {
}

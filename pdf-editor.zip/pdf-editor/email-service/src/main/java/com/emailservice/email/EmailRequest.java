package com.emailservice.email;

public record EmailRequest(
        String recipient,

) {
}

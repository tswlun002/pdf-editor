package com.emailservice.email;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class EmailConfig {
    @Value("${MAIL_HOST}")
    private  String HOST_MAIL;
    @Value("${MAIL_USERNAME}")
    private  String EMAIL;
    @Value("${MAIL_PASSWORD}")
    private  String PASSWORD;
    @Value("${MAIL_PROTOCOL}")
    private  String PROTOCOL;
    @Value("${MAIL_PORT}")
    private  int PORT;
    @Bean
    public JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(HOST_MAIL);
        mailSender.setPort(PORT);
        mailSender.setUsername(EMAIL);
        mailSender.setPassword(PASSWORD);
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", PROTOCOL);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true");

        return mailSender;
    }

}

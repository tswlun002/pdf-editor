package com.emailservice.email;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@AllArgsConstructor
@RequestMapping("pdf-editor/email")
@Validated
public class EmailController {
    @PostMapping("/send")
    public ResponseEntity<?>  sendEmail(HttpServletRequest request) throws ServletException, IOException {

        var sendEmailRequest = request.getPart("email");
       var pdfFile = request.getPart("pdf");
       if(sendEmailRequest==null) throw  new RuntimeException("Null email request");
       EmailRequest emailBody = new ObjectMapper().readValue(sendEmailRequest.getInputStream().readAllBytes(),EmailRequest.class);

    }
}

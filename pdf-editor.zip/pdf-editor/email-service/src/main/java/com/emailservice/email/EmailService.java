package com.emailservice.email;

import jakarta.validation.constraints.Email;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Properties;
@Service
public class EmailService {
    @Value("${mail.host}")
    private  String HOST_MAIL;
    @Value("${mail.protocol}")
    private  String PROTOCOL;

    public boolean sendEmail(@Email String recipient,DataSource source  ) {
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", PROTOCOL);
        Session session = Session.getDefaultInstance(properties);
        var sent =false;
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(HOST_MAIL));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            message.setSubject("EDITED PDF FILE");
            message.setText("Message");

            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();

            // Fill the message
            messageBodyPart.setText(String.format("Hi %s,\nThe pdf file is attached on this email." +
                    "\nregards,\npdf-editor","Lunga"));

            // Create a multipart message
            Multipart multipart = new MimeMultipart();

            // Set text message part
            multipart.addBodyPart(messageBodyPart);

            // Part two is attachment
            messageBodyPart = new MimeBodyPart();
            //String filename = "file.txt";
           // DataSource source = new FileDataSource(filename);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(source.getName());
            multipart.addBodyPart(messageBodyPart);

            // Send the complete message parts
            message.setContent(multipart);

            Transport.send(message);
            sent=true;
            System.out.println("Sent message successfully....");
        } catch (
                MessagingException mex) {
            mex.printStackTrace();
        }
        return sent;
    }
}
